---
title: about
date: 2016-05-10 13:49:02
---

## ABOUT
![SUMMER'S](http://ww4.sinaimg.cn/large/e6a4355cgw1f3tt17t33gj20dw08nq3r.jpg)


如果你发现这里, 说明你对我还算感兴趣.

iOS开发者
喜欢安静的夜写代码
喜欢思考人生---说白了就是闲的蛋疼
简书推荐作者 夏天然后 | 伯乐在线专栏作者(iOS)
微博 @夏天是个大人了
xttoboy@gmail.com


<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=421137034&auto=1&height=66"></iframe>
